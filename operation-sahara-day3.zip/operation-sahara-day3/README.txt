This folder contains your full Day 3 mission for Operation Sahara.

You will work with:
- Folders and files
- Permissions and users
- Logs
- Processes and PIDs
- Scripts
- Automation with cron

Start inside the mission folder.

Do not delete important files.
Do not rename the main folders:
- mission
- workspace
- logs

Follow the instructions inside mission/instructions.txt.